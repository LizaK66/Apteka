from flask import Flask, render_template_string, request, redirect, url_for, flash, session
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
import datetime
from functools import wraps

app = Flask(__name__)
app.secret_key = 'your-secret-key'
DATABASE = 'pharmacy.db'


# Вспомогательные функции для работы с БД
def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with get_db() as db:
        # Создаем таблицу пользователей
        db.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            is_admin BOOLEAN DEFAULT FALSE
        )
        """)

        # Создаем таблицу товаров
        db.execute("""
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            price REAL NOT NULL,
            quantity INTEGER NOT NULL,
            category TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """)

        # Проверяем, есть ли администратор
        admin = db.execute("SELECT * FROM users WHERE username = 'admin'").fetchone()
        if not admin:
            password_hash = generate_password_hash('admin123')
            db.execute(
                "INSERT INTO users (username, password_hash, is_admin) VALUES (?, ?, ?)",
                ('admin', password_hash, True)
            )
        db.commit()

        # Создаем таблицу для корзины
        db.execute("""
            CREATE TABLE IF NOT EXISTS shopping_cart (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                description TEXT,
                price REAL NOT NULL,
                quantity INTEGER NOT NULL,
                category TEXT, 
                user_id INTEGER NOT NULL
                )
                """)


# Декоратор для проверки авторизации
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Пожалуйста, войдите в систему')
            return redirect(url_for('login'))
        return f(*args, **kwargs)

    return decorated_function


# Проверяет права администратора
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Пожалуйста, войдите в систему')
            return redirect(url_for('login'))

        with get_db() as db:
            user = db.execute(
                "SELECT is_admin FROM users WHERE id = ?",
                (session['user_id'],)
            ).fetchone()

            if not user:
                flash('Пользователь не найден')
                return redirect(url_for('login'))

        return f(*args, **kwargs)

    return decorated_function


# Маршруты
@app.route('/')
def home():
    if 'user_id' in session:
        with get_db() as db:
            user = db.execute(
                "SELECT is_admin FROM users WHERE id = ?",
                (session['user_id'],)
            ).fetchone()

    return redirect(url_for('login'))


# Страница входа с формой
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        with get_db() as db:
            user = db.execute(
                "SELECT * FROM users WHERE username = ?",
                (username,)
            ).fetchone()

            if user and check_password_hash(user['password_hash'], password):
                session['user_id'] = user['id']
                session['is_admin'] = user['is_admin']

                if user['is_admin']:
                    return redirect(url_for('admin_dashboard'))
                else:
                    return redirect(url_for('customer_dashboard'))
            else:
                flash('Неверное имя пользователя или пароль')

    return render_template_string("""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Вход</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body class="bg-light">
        <div class="container mt-5">
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="text-center">Вход в систему</h3>
                        </div>
                        <div class="card-body">
                            {% with messages = get_flashed_messages() %}
                                {% if messages %}
                                    {% for message in messages %}
                                        <div class="alert alert-danger">{{ message }}</div>
                                    {% endfor %}
                                {% endif %}
                            {% endwith %}
                            <form method="POST">
                                <div class="mb-3">
                                    <label for="username" class="form-label">Имя пользователя</label>
                                    <input type="text" class="form-control" id="username" name="username" required>
                                </div>
                                <div class="mb-3">
                                    <label for="password" class="form-label">Пароль</label>
                                    <input type="password" class="form-control" id="password" name="password" required>
                                </div>
                                <button type="submit" class="btn btn-primary w-100">Войти</button>
                            </form>
                            <a href="{{ url_for('register_page') }}" target="_blank" class="btn btn-secondary w-100 mt-2">Регистрация</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
    </html>
    """)


# Регистрация
@app.route('/register', methods=['POST'])
def register():
    username = request.form['username']
    password = request.form['password']

    password_hash = generate_password_hash(password)

    with get_db() as db:
        existing_user = db.execute(
            "SELECT * FROM users WHERE username = ?",
            (username,)
        ).fetchone()

        if existing_user:
            flash('Имя пользователя уже существует. Пожалуйста, выберите другое имя.', 'danger')
            return redirect(url_for('register_page'))
        else:
            db.execute(
                "INSERT INTO users (username, password_hash) VALUES (?, ?)",
                (username, password_hash)
            )
            db.commit()
            flash('Регистрация прошла успешно! Вы можете войти в систему.')
    return redirect(url_for('login'))


# Панель регистрации
@app.route('/register_page', methods=['GET'])
def register_page():
    return render_template_string("""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Регистрация</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body class="bg-light">
        <div class="container mt-5">
            <h3>Регистрация</h3>

            {% with messages = get_flashed_messages() %}
                {% if messages %}
                    {% for message in messages %}
                        <div class="alert alert-danger">{{ message }}</div>
                    {% endfor %}
                {% endif %}
            {% endwith %}

            <form method="POST" action="{{ url_for('register') }}">
                <div class="mb-3">
                    <label for="new_username" class="form-label">Имя пользователя</label>
                    <input type="text" class="form-control" id="new_username" name="username" required>
                </div>
                <div class="mb-3">
                    <label for="new_password" class="form-label">Пароль</label>
                    <input type="password" class="form-control" id="new_password" name="password" required>
                </div>
                <button type="submit" class='btn btn-primary w-100'>Зарегистрироваться</button>
                <a href="{{ url_for('login') }}" class='btn btn-secondary w-100 mt-2'>Назад к входу</a>
            </form>
        </div>
    </body>
    </html>
    """)


# Выход из системы
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))


# Административная панель
@app.route('/admin/dashboard')
@login_required
@admin_required
def admin_dashboard():
    with get_db() as db:
        products = db.execute("SELECT * FROM products").fetchall()

    return render_template_string("""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Панель администратора</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container">
                <a class="navbar-brand" href="#">Аптека - Админ панель</a>
                <div class="navbar-nav">
                    <a class="nav-link" href="{{ url_for('logout') }}">Выйти</a>
                </div>
            </div>
        </nav>

        <div class="container mt-4">
            {% with messages = get_flashed_messages() %}
                {% if messages %}
                    {% for message in messages %}
                        <div class="alert alert-success">{{ message }}</div>
                    {% endfor %}
                {% endif %}
            {% endwith %}

            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2>Список товаров</h2>
                <a href="{{ url_for('add_product') }}" class="btn btn-success">Добавить товар</a>
            </div>

            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Название</th>
                        <th>Описание</th>
                        <th>Цена</th>
                        <th>Количество</th>
                        <th>Категория</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    {% for product in products %}
                        <tr>
                            <td>{{ product['id'] }}</td>
                            <td>{{ product['name'] }}</td>
                            <td>{{ product['description'] }}</td>
                            <td>{{ product['price'] }}</td>
                            <td>{{ product['quantity'] }}</td>
                            <td>{{ product['category'] }}</td>
                            <td>
                                <a href="{{ url_for('edit_product', id=product['id']) }}" class="btn btn-sm btn-primary">Редактировать</a>
                                <form method="POST" action="{{ url_for('delete_product', id=product['id']) }}" style="display: inline;">
                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Вы уверены?')">Удалить</button>
                                </form>
                            </td>
                        </tr>
                    {% endfor %}
                </tbody>
            </table>
        </div>
    </body>
    </html>
    """, products=products)


# Добавление нового товара
@app.route('/admin/products/add', methods=['GET', 'POST'])
@login_required
@admin_required
def add_product():
    if request.method == 'POST':
        name = request.form['name']
        description = request.form['description']
        price = float(request.form['price'])
        quantity = int(request.form['quantity'])
        category = request.form['category']

        with get_db() as db:
            db.execute(
                "INSERT INTO products (name, description, price, quantity, category) VALUES (?, ?, ?, ?, ?)",
                (name, description, price, quantity, category)
            )
            db.commit()

        flash('Товар успешно добавлен')
        return redirect(url_for('admin_dashboard'))

    return render_template_string("""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Добавить товар</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container">
                <a class="navbar-brand" href="#">Аптека - Админ панель</a>
                <div class="navbar-nav">
                    <a class="nav-link" href="{{ url_for('logout') }}">Выйти</a>
                </div>
            </div>
        </nav>

        <div class="container mt-4">
            <h2>Добавить товар</h2>
            <form method="POST">
                <div class="mb-3">
                    <label for="name" class="form-label">Название</label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>
                <div class="mb-3">
                    <label for="description" class="form-label">Описание</label>
                    <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                </div>
                <div class="mb-3">
                    <label for="price" class="form-label">Цена</label>
                    <input type="number" step="0.01" class="form-control" id="price" name="price" required>
                </div>
                <div class="mb-3">
                    <label for="quantity" class="form-label">Количество</label>
                    <input type="number" class="form-control" id="quantity" name="quantity" required>
                </div>
                <div class="mb-3">
                    <label for="category" class="form-label">Категория</label>
                    <input type="text" class="form-control" id="category" name="category">
                </div>
                <button type="submit" class="btn btn-primary">Сохранить</button>
                <a href="{{ url_for('admin_dashboard') }}" class="btn btn-secondary">Отмена</a>
            </form>
        </div>
    </body>
    </html>
    """)


# Редактирование существующего товара
@app.route('/admin/products/edit/<int:id>', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_product(id):
    with get_db() as db:
        product = db.execute("SELECT * FROM products WHERE id = ?", (id,)).fetchone()

    if not product:
        flash('Товар не найден')
        return redirect(url_for('admin_dashboard'))

    if request.method == 'POST':
        name = request.form['name']
        description = request.form['description']
        price = float(request.form['price'])
        quantity = int(request.form['quantity'])
        category = request.form['category']

        with get_db() as db:
            db.execute(
                """UPDATE products SET 
                    name = ?, 
                    description = ?, 
                    price = ?, 
                    quantity = ?, 
                    category = ?, 
                    updated_at = CURRENT_TIMESTAMP 
                WHERE id = ?""",
                (name, description, price, quantity, category, id)
            )
            db.commit()

        flash('Товар успешно обновлен')
        return redirect(url_for('admin_dashboard'))

    return render_template_string("""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Редактировать товар</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container">
                <a class="navbar-brand" href="#">Аптека - Админ панель</a>
                <div class="navbar-nav">
                    <a class="nav-link" href="{{ url_for('logout') }}">Выйти</a>
                </div>
            </div>
        </nav>

        <div class="container mt-4">
            <h2>Редактировать товар</h2>
            <form method="POST">
                <div class="mb-3">
                    <label for="name" class="form-label">Название</label>
                    <input type="text" class="form-control" id="name" name="name" value="{{ product['name'] }}" required>
                </div>
                <div class="mb-3">
                    <label for="description" class="form-label">Описание</label>
                    <textarea class="form-control" id="description" name="description" rows="3">{{ product['description'] }}</textarea>
                </div>
                <div class="mb-3">
                    <label for="price" class="form-label">Цена</label>
                    <input type="number" step="0.01" class="form-control" id="price" name="price" value="{{ product['price'] }}" required>
                </div>
                <div class="mb-3">
                    <label for="quantity" class="form-label">Количество</label>
                    <input type="number" class="form-control" id="quantity" name="quantity" value="{{ product['quantity'] }}" required>
                </div>
                <div class="mb-3">
                    <label for="category" class="form-label">Категория</label>
                    <input type="text" class="form-control" id="category" name="category" value="{{ product['category'] }}">
                </div>
                <button type="submit" class="btn btn-primary">Обновить</button>
                <a href="{{ url_for('admin_dashboard') }}" class="btn btn-secondary">Отмена</a>
            </form>
        </div>
    </body>
    </html>
    """, product=product)


# Удаление товара
@app.route('/admin/products/delete/<int:id>', methods=['POST'])
@login_required
@admin_required
def delete_product(id):
    with get_db() as db:
        db.execute("DELETE FROM products WHERE id = ?", (id,))
        db.commit()

    flash('Товар успешно удален')
    return redirect(url_for('admin_dashboard'))


# Понель покупателя
@app.route('/customer/dashboard')
@login_required
@admin_required
def customer_dashboard():
    with get_db() as db:
        products = db.execute("SELECT * FROM products").fetchall()

    return render_template_string("""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Пользователь</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container">
                <a class="navbar-brand" href="#">Аптека</a>
                <div class="navbar-nav">
                    <a class="nav-link" href="{{ url_for('logout') }}">Выйти</a>
                </div>
            </div>
        </nav>

        <div class="container mt-4">
            {% with messages = get_flashed_messages() %}
                {% if messages %}
                    {% for message in messages %}
                        <div class="alert alert-success">{{ message }}</div>
                    {% endfor %}
                {% endif %}
            {% endwith %}

            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2>Список товаров</h2>
                <a href="{{ url_for('shopping_cart') }}" class="btn btn-success">Корзина</a>
            </div>

            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Название</th>
                        <th>Описание</th>
                        <th>Цена</th>
                        <th>Количество</th>
                        <th>Категория</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    {% for product in products %}
                        <tr>
                            <td>{{ product['id'] }}</td>
                            <td>{{ product['name'] }}</td>
                            <td>{{ product['description'] }}</td>
                            <td>{{ product['price'] }}</td>
                            <td>{{ product['quantity'] }}</td>
                            <td>{{ product['category'] }}</td>
                            <td>
                                <form method="POST" action="{{ url_for('add_to_shopping_cart', id=product['id']) }}" style="display: inline;">
                                    <input type="hidden" name="name" value="{{ product['name'] }}">
                                    <input type="hidden" name="description" value="{{ product['description'] }}">
                                    <input type="hidden" name="price" value="{{ product['price'] }}">
                                    <input type="hidden" name="quantity" value="{{ product['quantity'] }}">
                                    <input type="hidden" name="category" value="{{ product['category'] }}">
                                    <button type="submit" class="btn btn-sm btn-success">В корзину</button>
                                </form>
                            </td>
                        </tr>
                    {% endfor %}
                </tbody>
            </table>
        </div>
    </body>
    </html>
    """, products=products)


# Добавление товара в корзину
@app.route('/customer/products/add', methods=['GET', 'POST'])
@login_required
@admin_required
def add_to_shopping_cart():
    if request.method == 'POST':
        name = request.form['name']
        description = request.form['description']
        price = float(request.form['price'])
        quantity = int(request.form['quantity'])
        category = request.form['category']
        user_id = session['user_id']

        with get_db() as db:
            db.execute(
                "INSERT INTO shopping_cart (name, description, price, quantity, category, user_id) VALUES (?, ?, ?, ?, ?, ?)",
                (name, description, price, quantity, category, user_id)
            )
            db.commit()

        flash('Товар успешно добавлен')
        return redirect(url_for('customer_dashboard'))


# Корзина
@app.route('/customer/products/shopping_cart', methods=['GET', 'POST'])
@login_required
@admin_required
def shopping_cart():
    user_id = session['user_id']

    # Отображаются только товыры добавленные пользователе, в аккауте которого накодимся
    with get_db() as db:
        products = db.execute(
            "SELECT * FROM shopping_cart WHERE user_id = ?", (user_id,)).fetchall()

    return render_template_string("""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Пользователь</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container">
                <a class="navbar-brand" href="#">Аптека - Корзина</a>
                <div class="navbar-nav">
                    <a class="nav-link" href="{{ url_for('logout') }}">Выйти</a>
                </div>
            </div>
        </nav>

        <div class="container mt-4">
            {% with messages = get_flashed_messages() %}
                {% if messages %}
                    {% for message in messages %}
                        <div class="alert alert-success">{{ message }}</div>
                    {% endfor %}
                {% endif %}
            {% endwith %}

            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2>Список товаров</h2>
            </div>


            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Название</th>
                        <th>Описание</th>
                        <th>Цена</th>
                        <th>Количество</th>
                        <th>Категория</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    {% for product in products %}
                        <tr>
                            <td>{{ product['name'] }}</td>
                            <td>{{ product['description'] }}</td>
                            <td>{{ product['price'] }}</td>
                            <td>
                                <input type="number" name="quantity_{{ product['id'] }}" value="1" min="1" style="width: 60px;">
                            </td>
                            <td>{{ product['category'] }}</td>
                            <td>
                                <form method="POST" action="{{ url_for('delete_product_cart', id=product['id']) }}" style="display: inline;">
                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Вы уверены?')">Удалить</button>
                                </form>
                            </td>
                        </tr>
                    {% endfor %}
                </tbody>
            </table>
            {% if not products %}
                <p>Ваша корзина пуста.</p> <!-- Сообщение о пустой корзине -->
            {% endif %}
        </div>
    </body>
    </html>
    """, products=products)


# Удаление товара из корзины
@app.route('/customer/products/delete/<int:id>', methods=['POST'])
@login_required
@admin_required
def delete_product_cart(id):
    with get_db() as db:
        db.execute("DELETE FROM shopping_cart WHERE id = ?", (id,))
        db.commit()

    flash('Товар успешно удален')
    return redirect(url_for('shopping_cart'))


if __name__ == '__main__':
    init_db()
    app.run(debug=True)